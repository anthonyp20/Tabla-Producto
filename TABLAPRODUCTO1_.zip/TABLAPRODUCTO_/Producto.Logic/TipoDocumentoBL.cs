﻿using Producto.Data;
using Producto.Dominio;
using System;
using System.Collections.Generic;
using System.Text;

namespace Producto.Logic
{
    class TipoDocumentoBL
    {
        public static List<TipoDocumento> Listar()
        {
            var tipoDocumentoData = new TipoDocumentoData();
            return tipoDocumentoData.Listar();
        }
    }
}
