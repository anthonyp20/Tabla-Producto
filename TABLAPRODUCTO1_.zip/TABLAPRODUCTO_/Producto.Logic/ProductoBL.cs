﻿using System;
using Producto.Data;

using System.Collections.Generic;
using Producto.Dominio;

namespace Producto.Logic
{
    public class ProductoBL
    {
        public static List<Cliente> Listar()
        {
            var clienteData = new ClienteData();
            return clienteData.Listar();
        }

        public static Cliente BuscarPorId(int id)
        {
            var clienteData = new ClienteData();
            return clienteData.BuscarPorId(id);
        }

        public static bool Insertar(Cliente cliente)
        {
            var clienteData = new ClienteData();
            return clienteData.Insertar(cliente);
        }

        public static bool Actualizar(Cliente cliente)
        {
            var clienteData = new ClienteData();
            return clienteData.Actualizar(cliente);
        }

        public static bool Eliminar(int id)
        {
            var clienteData = new ClienteData();
            return clienteData.Eliminar(id);
        }

        
    }
}
