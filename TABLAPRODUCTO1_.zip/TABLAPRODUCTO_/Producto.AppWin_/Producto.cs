﻿using Producto.Dominio;
using Producto.Logic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Producto.AppWin_
{
    public partial class Producto : Form
    {
        public Producto()
        {
            InitializeComponent();
        }

        private void tsbNuevo_Click(object sender, EventArgs e)
        {
            
        }

        private void cargarDatos()
        {
            var listado = Logic.ProductoBL.Listar();
            dgvListado.Rows.Clear();
            foreach (var cliente in listado)
            {
                dgvListado.Rows.Add(cliente.ID, cliente.Nombres, cliente.Marca, cliente.Precio, cliente.Stock);
            }
        }

        private void nuevoRegistro(object sender, EventArgs e)
        {
            var nuevoCliente = new Cliente();
            var Producto= new ProductoEdit(nuevoCliente);
            if (Producto.ShowDialog() == DialogResult.OK)
            {
                var exito = ProductoBL.Insertar(nuevoCliente);
                if (exito)
                {
                    MessageBox.Show("El cliente ha sido registrado", "Financiera",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cargarDatos();
                }
                else
                {
                    MessageBox.Show("No se ha podido registrar al cliente", "Financiera",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void editarRegistro(object sender, EventArgs e)
        {
            if (dgvListado.Rows.Count > 0)
            {
                int filaActual = dgvListado.CurrentRow.Index;
                var idCliente = int.Parse(dgvListado.Rows[filaActual].Cells[0].Value.ToString());
                var clienteEditar = Logic.ProductoBL.BuscarPorId(idCliente);
                var ProductoEdit= new ProductoEdit(clienteEditar);
                if (ProductoEdit.ShowDialog() == DialogResult.OK)
                {
                    var exito = Logic.ProductoBL.Actualizar(clienteEditar);
                    if (exito)
                    {
                        MessageBox.Show("El cliente ha sido actualizado", "Producto",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        cargarDatos();
                    }
                    else
                    {
                        MessageBox.Show("No se ha podido completar la operación de actualización",
                            "Producto", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void EliminarRegistro(object sender, EventArgs e)
        {

        }

        private void iniciarFormulario(object sender, EventArgs e)
        {
            cargarDatos();
        }
    }
}
