﻿using Producto.Dominio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Producto.AppWin_
{
    public partial class ProductoEdit : Form
    {

        Cliente cliente;
        public ProductoEdit(Cliente cliente)
        {
            InitializeComponent();
            this.cliente = cliente;
        }

        public ProductoEdit()
        {
        }

        private void ClienteEdit_Load(object sender, EventArgs e)
        {

        }

        private void iniciarFormulario(object sender, EventArgs e)
        {

        }
        public void cargarDatos()
        {

        }

        private void grabarDatos(object sender, EventArgs e)
        {

        }

        private void btnGrabar_Click(object sender, EventArgs e)
        {
            asignarObjeto();
            this.DialogResult = DialogResult.OK;
        }
        private void asignarObjeto()
        {
            cliente.Nombres = txtNombre.Text;
            cliente.Marca = txtMarca.Text;
            cliente.Precio = txtPrecio.Text;
            cliente.Stock = txtStock.Text;

            cliente.Estado = chkEstado.Checked;
        }

        private void asignarControles()
        {
            txtNombre.Text = cliente.Nombres;
            txtMarca.Text = cliente.Marca;
            txtPrecio.Text = cliente.Precio;
            txtStock.Text = cliente.Stock;

            chkEstado.Checked = cliente.Estado;
        }

        public static implicit operator ProductoEdit(Producto v)
        {
            throw new NotImplementedException();
        }
    }
}
