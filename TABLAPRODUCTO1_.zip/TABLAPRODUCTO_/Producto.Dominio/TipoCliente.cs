﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Producto.Dominio
{
    public class TipoCliente
    {
       
        public string Nombre { get; set; }
        public bool Estado { get; set; }
    }
}
