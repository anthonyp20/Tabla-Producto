﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Producto.Dominio
{
    public class DetallePrestamo
    {
       
        public int IdPrestamo { get; set; }
        public int NumeroCuota { get; set; }
        public decimal ImporteCuota { get; set; }
        public DateTime FechaVencimiento { get; set; }
        public bool Estado { get; set; }
    }
}
