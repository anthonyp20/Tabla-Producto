﻿using System;

namespace Producto.Dominio
{
    public class Cliente
    {
        public int ID { get; set; }
        public string Nombres { get; set; }
        public string Marca { get; set; }
        public string Precio { get; set; }
        public string Stock { get; set; }
        public bool Estado { get; set; }

        public static object Insertar(Cliente cliente)
        {
            throw new NotImplementedException();
        }

        
    }
}
