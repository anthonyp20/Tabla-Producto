﻿using Producto.Data;
using Producto.Dominio;
using System;
using System.Collections.Generic;
using System.Text;

namespace Producto.Logic
{
    public class TipoProductoBL
    {
        public static List<TipoCliente> Listar()
        {
            var tipoCLienteData = new TipoClienteData();
            return tipoCLienteData.Listar();
        }
    }
}
